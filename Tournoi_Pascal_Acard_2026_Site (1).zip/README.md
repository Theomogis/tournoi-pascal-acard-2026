# Tournoi Pascal Acard 2026

Site officiel du tournoi de l'Olympique Pavillais.

## Étapes pour mise en ligne
1. Ouvrez index.html et collez vos URLs de Google Sheets (Matches et Teams).
2. Publiez ce dossier sur GitHub Pages.

Contact : 500223@lfnfoot.com | Grégory Meunier